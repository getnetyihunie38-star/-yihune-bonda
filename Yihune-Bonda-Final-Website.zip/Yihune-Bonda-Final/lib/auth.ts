import crypto from "crypto";
import { cookies } from "next/headers";

export const COOKIE_NAME = "yb_admin";
const secret = () => process.env.SESSION_SECRET || "";
const sign = (value: string) => crypto.createHmac("sha256", secret()).update(value).digest("hex");

export function createSession() {
  const value = `${Date.now()}.${crypto.randomBytes(24).toString("hex")}`;
  return `${value}.${sign(value)}`;
}

export function validSession(value?: string) {
  if (!value || !secret()) return false;
  const parts = value.split(".");
  if (parts.length !== 3) return false;
  const expected = sign(`${parts[0]}.${parts[1]}`);
  const actual = parts[2];
  if (actual.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(actual), Buffer.from(expected));
}

export async function isAdmin() {
  const store = await cookies();
  return validSession(store.get(COOKIE_NAME)?.value);
}
