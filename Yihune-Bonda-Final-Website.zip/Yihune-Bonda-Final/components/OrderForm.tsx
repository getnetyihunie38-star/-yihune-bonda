"use client";
import {useState} from "react";
export default function OrderForm({initialProduct}:{initialProduct:string}){
 const [f,setF]=useState({customer_name:"",phone:"",product_name:initialProduct,size:"",color:"",quantity:"1",note:""});
 const [status,setStatus]=useState<""|"loading"|"ok"|"error">("");
 const [message,setMessage]=useState("");
 const change=(e:React.ChangeEvent<HTMLInputElement|HTMLTextAreaElement>)=>setF(v=>({...v,[e.target.name]:e.target.value}));
 async function submit(e:React.FormEvent){e.preventDefault();setStatus("loading");setMessage("");try{const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...f,quantity:Number(f.quantity)})});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||"error");setStatus("ok");setMessage("ትዕዛዝዎ ተልኳል።");setF(v=>({...v,customer_name:"",phone:"",note:"",quantity:"1"}));}catch{setStatus("error");setMessage("ትዕዛዙ አልተላከም። Database እና የVercel settings ያረጋግጡ።")}}
 return <form className="form" onSubmit={submit}>{message&&<div className={`notice ${status==="error"?"error":""}`}>{message}</div>}
  <label className="field"><span>ስም *</span><input name="customer_name" required value={f.customer_name} onChange={change}/></label>
  <label className="field"><span>ስልክ *</span><input name="phone" required inputMode="tel" value={f.phone} onChange={change}/></label>
  <label className="field"><span>ምርት *</span><input name="product_name" required value={f.product_name} onChange={change}/></label>
  <label className="field"><span>መጠን</span><input name="size" placeholder="S, M, L, XL" value={f.size} onChange={change}/></label>
  <label className="field"><span>ቀለም</span><input name="color" value={f.color} onChange={change}/></label>
  <label className="field"><span>ብዛት</span><input name="quantity" type="number" min="1" required value={f.quantity} onChange={change}/></label>
  <label className="field"><span>ማስታወሻ</span><textarea name="note" value={f.note} onChange={change}/></label>
  <button className="btn" disabled={status==="loading"}>{status==="loading"?"በመላክ ላይ...":"ትዕዛዝ ላክ"}</button>
 </form>
}
