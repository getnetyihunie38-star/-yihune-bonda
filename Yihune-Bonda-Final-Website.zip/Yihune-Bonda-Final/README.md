# Yihune Bonda – Final Website

Next.js + Neon Postgres + Vercel Blob. The site has Amharic customer pages, product management, image upload, order collection, and password-protected admin.

## Vercel setup
1. Import this repository as a Next.js project.
2. Add a Neon Postgres database and run `db/schema.sql` once.
3. Create a Vercel Blob store and add its `BLOB_READ_WRITE_TOKEN`.
4. Add environment variables from `.env.example` for Production and Preview.
5. Redeploy.

Required: `DATABASE_URL`, `BLOB_READ_WRITE_TOKEN`, `ADMIN_PASSWORD`, `SESSION_SECRET`. Optional: `SHOP_PHONE`, `SHOP_WHATSAPP`.
