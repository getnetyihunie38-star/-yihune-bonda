import Link from "next/link";
import {db} from "../../lib/db";
export const dynamic="force-dynamic";
type Product={id:number;name:string;price:number;sizes:string[];color:string;description:string;image_url:string};
export default async function Products(){
  let products:Product[]=[]; let configured=true;
  try{products=await db()<Product[]>`SELECT id,name,price::float8 AS price,sizes,color,description,image_url FROM products ORDER BY created_at DESC`;}catch{configured=false;}
  return <main className="section"><div className="container"><div className="topline"><div><h1>ምርቶች</h1><p className="muted">የሚገኙ ምርቶችን ይመልከቱ።</p></div><Link className="btn" href="/order">ትዕዛዝ</Link></div>
    {!configured?<div className="notice error">Database ገና አልተገናኘም። Vercel Environment Variables ላይ DATABASE_URL ያስገቡ።</div>:!products.length?<div className="notice">እስካሁን ምርት የለም። Admin ገጽ ላይ ይጨምሩ።</div>:<div className="grid">{products.map(p=><article className="card" key={p.id}>{p.image_url&&<img src={p.image_url} alt={p.name}/>}<div className="body"><h2>{p.name}</h2><div className="price">{Number(p.price).toLocaleString("en-US")} ብር</div><p className="muted">{p.color}{p.sizes?.length?` • ${p.sizes.join(", ")}`:""}</p><p>{p.description}</p><Link className="btn" href={`/order?product=${encodeURIComponent(p.name)}`}>ይዘዙ</Link></div></article>)}</div>}
  </div></main>
}
