import {NextResponse} from "next/server";
import {db} from "../../../lib/db";
export async function POST(request:Request){
 try{const b=await request.json();const name=String(b.customer_name||"").trim(),phone=String(b.phone||"").trim(),product=String(b.product_name||"").trim();const quantity=Math.max(1,Math.floor(Number(b.quantity)||1));if(!name||!phone||!product)return NextResponse.json({error:"required"},{status:400});await db()`INSERT INTO orders(customer_name,phone,product_name,size,color,quantity,note) VALUES(${name},${phone},${product},${String(b.size||"")},${String(b.color||"")},${quantity},${String(b.note||"")})`;return NextResponse.json({ok:true});}catch(e){console.error(e);return NextResponse.json({error:"database"},{status:500})}
}
