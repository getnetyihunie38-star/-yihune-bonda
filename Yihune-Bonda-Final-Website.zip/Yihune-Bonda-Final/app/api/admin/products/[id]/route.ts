import {NextResponse} from "next/server";
import {isAdmin} from "../../../../../lib/auth";
import {db} from "../../../../../lib/db";
export async function DELETE(_request:Request,{params}:{params:Promise<{id:string}>}){if(!(await isAdmin()))return NextResponse.json({error:"unauthorized"},{status:401});const id=Number((await params).id);if(!Number.isInteger(id))return NextResponse.json({error:"invalid id"},{status:400});await db()`DELETE FROM products WHERE id=${id}`;return NextResponse.json({ok:true});}
