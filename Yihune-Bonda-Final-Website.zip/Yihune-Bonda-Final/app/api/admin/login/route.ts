import {NextResponse} from "next/server";
import {COOKIE_NAME,createSession} from "../../../../lib/auth";
export async function POST(request:Request){const b=await request.json().catch(()=>({}));const password=String(b.password||"");if(!process.env.ADMIN_PASSWORD||password!==process.env.ADMIN_PASSWORD)return NextResponse.json({error:"unauthorized"},{status:401});const response=NextResponse.json({ok:true});response.cookies.set(COOKIE_NAME,createSession(),{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:60*60*24*7});return response;}
