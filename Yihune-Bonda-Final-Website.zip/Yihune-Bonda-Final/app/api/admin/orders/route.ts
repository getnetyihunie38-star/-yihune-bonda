import {NextResponse} from "next/server";
import {isAdmin} from "../../../../lib/auth";
import {db} from "../../../../lib/db";
export async function GET(){if(!(await isAdmin()))return NextResponse.json({error:"unauthorized"},{status:401});return NextResponse.json(await db()`SELECT id,customer_name,phone,product_name,size,color,quantity,note,created_at FROM orders ORDER BY created_at DESC`);}
