import OrderForm from "../../components/OrderForm";
export default async function Order({searchParams}:{searchParams:Promise<{product?:string}>}){const params=await searchParams;return <main className="section"><div className="container"><h1>ትዕዛዝ ይላኩ</h1><p className="muted">የእርስዎን መረጃ ያስገቡ።</p><OrderForm initialProduct={params.product||""}/></div></main>}
