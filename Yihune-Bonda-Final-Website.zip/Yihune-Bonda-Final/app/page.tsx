import Link from "next/link";
export default function Home(){return <main>
  <section className="hero"><div className="container"><p className="small">ባህርዳር • ዋርካው ህንፃ</p><h1>Yihune Bonda</h1><p>ምርቶቻችንን በፎቶ፣ ዋጋ፣ መጠን እና ቀለም ይመልከቱ። በቀላሉ ይዘዙ።</p><div className="actions"><Link className="btn" href="/products">ምርቶችን ይመልከቱ</Link><Link className="btn secondary" href="/order">ትዕዛዝ ላክ</Link></div></div></section>
  <section className="section"><div className="container grid"><div className="card"><div className="body"><h2>ቀላል ትዕዛዝ</h2><p>ምርት ይምረጡ፣ የስልክ ቁጥርዎን ያስገቡ እና ትዕዛዝዎን ይላኩ።</p></div></div><div className="card"><div className="body"><h2>ፎቶ የተደገፉ ምርቶች</h2><p>Admin ገጹን በስልክም በኮምፒውተርም መጠቀም ይችላሉ።</p></div></div><div className="card"><div className="body"><h2>አድራሻ</h2><p>ባህርዳር ቀበሌ 4፣ ዋርካው ህንፃ፣ ግራውንድ 82</p></div></div></div></section>
</main>}
