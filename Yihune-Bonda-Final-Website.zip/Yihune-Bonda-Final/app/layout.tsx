import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Yihune Bonda | የዕቃ መደብር",
  description: "Yihune Bonda online shop"
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="am"><body>
    <header className="site-header"><div className="container nav">
      <Link href="/" className="brand">Yihune Bonda</Link>
      <nav><Link href="/">መነሻ</Link><Link href="/products">ምርቶች</Link><Link href="/order">ትዕዛዝ</Link><Link href="/admin">Admin</Link></nav>
    </div></header>
    {children}
    <footer className="site-footer"><div className="container footer-grid">
      <div><strong>Yihune Bonda</strong><p>ባህርዳር ቀበሌ 4 • ዋርካው ህንፃ • ግራውንድ 82</p></div>
      <div><p>ስልክ: {process.env.SHOP_PHONE || "0945571200"}</p><a className="whatsapp" href={`https://wa.me/${process.env.SHOP_WHATSAPP || "251945571200"}`}>WhatsApp</a></div>
    </div></footer>
  </body></html>;
}
